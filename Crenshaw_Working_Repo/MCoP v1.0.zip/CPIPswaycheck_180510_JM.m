[x,y,z,VAR]= COPSwayCheck(30,'C:\Users\Crenshaw Lab\Desktop\Matteson CPIP\Matlab Code\Test Files\CPIPcon09_PSclosed_00001b_f_2.tsv');
