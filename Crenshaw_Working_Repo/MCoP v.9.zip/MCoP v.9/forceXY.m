classdef forceXY < matlab.System
    %Object forceXY holds the data set and normalizes and filters the data
    %set. Most functions are simple get functions that may be unneccessary.
    %The each data set from raw->unfilt->forceSet holds its value so it
    %does not get normalized or filtered more than once.
        
    properties(Constant,Hidden)

        sRate = 600;%sampling Rate
        COfreq = 10;%Cutpff frequency
    end
    properties
        endTime = 30;
        unfiltForceSet;%raw data normalized to mean value
        forceSet;%filtered forceplate data using butterworth filt
        %Prietto Vars%%%%%%%%%%%%%%%%%%%%%%
        RMS;
        MDIST;
        TOTEX;
        MVELO;
        MFREQ;
        %%%%%%%%%%%%%%%%%%%%%%%%%%

    end
    properties(Access = protected)
        rawForceSet;%raw data with coords relative to FP origin
    end
    methods
        function obj = forceXY(array,hypotArray)
            if nargin < 2%%Filters and normalizes AP and ML arrays
                obj.rawForceSet = array; 
                obj.unfiltForceSet = downsample(obj.rawForceSet(1:obj.endTime*1200,:),2);%downsample to 120hz
                [z,p] = butter(2,10/(600/2));  %Assumes sampling frequency is 600 Hz, 2nd order, or forth order recursive
                obj.forceSet=filtfilt(z,p,obj.unfiltForceSet);%Filtering signal
                set(obj,'unfiltForceSet',(obj.unfiltForceSet-mean(obj.unfiltForceSet)));
                set(obj,'forceSet',(obj.forceSet-mean(obj.forceSet)));
            else 
                obj.forceSet = hypot(array,hypotArray);%For construction of the transverse plane data array and calulations
            end
            calcVar(obj);%initializes all prietto vars for data array
        end
        function calcVar(obj)
            obj.MDIST = mean(obj.forceSet);
            obj.RMS = rms(obj.forceSet);
            obj.TOTEX = sum(diff(obj.forceSet));
            obj.MVELO = obj.TOTEX/obj.endTime;
            obj.MFREQ = obj.MVELO/(2*pi*obj.MDIST);
        end
        function [RMS,MDIST,TOTEX,MVELO,MFREQ] = getForceVar(obj)
            MDIST = get(obj,'MDIST');
            RMS = get(obj,'RMS');
            TOTEX = get(obj,'TOTEX');
            MVELO = get(obj,'MVELO');
            MFREQ = get(obj,'MFREQ');
        end
        function val = get.forceSet(obj)
            val = obj.forceSet;
        end
        function val = get.RMS(obj)
            val = rms(obj.forceSet);
        end
        function val = get.MDIST(obj)
            val = mean(obj.forceSet);
        end
        function val = get.TOTEX(obj)
            val = sum(diff(obj.forceSet));
        end
        function val = std(obj)
           val = obj.RMS; 
        end
        function val = stdTV(obj)
           val = (obj.RMS^2-obj.MDIST^2)^(1/2);
        end
    end
end
